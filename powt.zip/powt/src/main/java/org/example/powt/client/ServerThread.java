package org.example.powt.client;

import org.example.powt.model.Dot;

import java.io.*;
import java.net.*;
import java.util.function.Consumer;

public class ServerThread extends Thread {
    private final Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Consumer<Dot> consumer;

    public ServerThread(String host, int port) throws IOException {
        socket = new Socket(host, port);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    public void send(int x, int y, String color, int radius) {
        out.println(Dot.toMessage(x, y, color, radius));
    }

    public void setConsumer(Consumer<Dot> consumer) {
        this.consumer = consumer;
    }

    @Override
    public void run() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                Dot dot = Dot.fromMessage(line);
                if (consumer != null) consumer.accept(dot);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
