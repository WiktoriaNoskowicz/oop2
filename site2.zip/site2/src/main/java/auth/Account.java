package auth;

public record Account(int id, String username) {}
