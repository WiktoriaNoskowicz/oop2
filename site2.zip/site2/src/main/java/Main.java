import auth.Account;
import auth.AccountManager;
import database.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//public class Main {
//    public static void main(String[] args) {
//        DatabaseConnection db = new DatabaseConnection();
//        String dbPath = "test.db"; // utworzy plik w folderze projektu
//
//        try {
//            db.connect(dbPath);
//            Connection conn = db.getConnection();
//            Statement stmt = conn.createStatement();
//
//            // Tworzenie tabeli
//            stmt.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT);");
//
//            // Wstawianie danych
//            stmt.execute("INSERT INTO users (name) VALUES ('Ala');");
//            stmt.execute("INSERT INTO users (name) VALUES ('Ola');");
//
//            // Odczyt danych
//            ResultSet rs = stmt.executeQuery("SELECT * FROM users;");
//            while (rs.next()) {
//                System.out.println("User ID: " + rs.getInt("id") + ", Name: " + rs.getString("name"));
//            }
//
//            rs.close();
//            stmt.close();
//        } catch (SQLException e) {
//            System.out.println("SQL Error: " + e.getMessage());
//        } finally {
//            try {
//                db.disconnect();
//            } catch (SQLException e) {
//                System.out.println("Disconnection error: " + e.getMessage());
//            }
//        } }}

        //ODPALANIE MAVENA
        // tworzymy nowy projekt i do pom.xml dodajemy
        //<build>
        //        <plugins>
        //            <plugin>
        //                <groupId>org.codehaus.mojo</groupId>
        //                <artifactId>exec-maven-plugin</artifactId>
        //                <version>3.4.1</version>
        //                <executions>
        //                    <execution>
        //                        <goals>
        //                            <goal>
        //                                java
        //                            </goal>
        //                        </goals>
        //                    </execution>
        //                </executions>
        //
        //                <configuration>
        //                    <mainClass>Main</mainClass> <!-- Bez pakietu -->
        // ewentualne -> tego nie kopiowac gdy chcemy odpalac z pakietu ->
        //              <mainClass>nazwaPakietu.KLASA</mainClass>
        //                </configuration>
        //            </plugin>
        //        </plugins>
        //    </build>
        // ladujemy mavena
        // odpadalnie main
        // -> package
        // -> exec -> exex:java -> w terminalu wynik !

        //dependency znajdujemy w maven https://mvnrepository.com/


//package music;

import database.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {

        try {
            Class.forName("org.sqlite.JDBC");
            System.out.println("SQLite driver loaded!");
        } catch (ClassNotFoundException e) {
            System.err.println("SQLite JDBC driver not found: " + e.getMessage());
        }

        // Zad.1

//        DatabaseConnection db = new DatabaseConnection();
//
//        try {
//            // można użyć nazwy pliku "test.db"
//            db.connect("test.db");
//            Connection conn = db.getConnection();
//
//            Statement stmt = conn.createStatement();
//
//            // 1. Tworzymy tabele
//            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)");
//
//            // 2. Dodajemy 2 rzedy
//            stmt.executeUpdate("INSERT INTO users (name) VALUES ('Alice')");
//            stmt.executeUpdate("INSERT INTO users (name) VALUES ('Bob')");
//
//            // 3. Czytamy te rzedy
//            ResultSet rs = stmt.executeQuery("SELECT * FROM users");
//
//            // 4. Wypisujemy je
//            while (rs.next()) {
//                int id = rs.getInt("id");
//                String name = rs.getString("name");
//                System.out.println("User ID: " + id + ", Name: " + name);
//            }
//
//            rs.close();
//            stmt.close();
//            db.disconnect();
//
//        } catch (SQLException e) {
//            System.out.println("Database error: " + e.getMessage());
//        }

        DatabaseConnection db = new DatabaseConnection();
        try {
            db.connect("accounts.db");
            Connection conn = db.getConnection();

            AccountManager accountManager = new AccountManager(conn);

            // Rejestrujemy użytkownika
            System.out.println("\n📥 Rejestracja:");
            accountManager.register("alice", "password123");
            accountManager.register("bob", "securePass");

            // Auth
            System.out.println("\n🔐 Testowanie logowania:");
            System.out.println("alice/password123: " + accountManager.authenticate("alice", "password123")); // true
            System.out.println("bob/wrongPass: " + accountManager.authenticate("bob", "wrongPass")); // false

            // Pobieramy konto za pomocą nazwy użytkownika
            System.out.println("\n📄 Pobieranie konta:");
            Account acc = accountManager.getAccount("alice");
            if (acc != null) {
                System.out.println("Znaleziono konto: id=" + acc.id() + ", username=" + acc.username());
            }

            // to samy za pomocą id
            if (acc != null) {
                Account accById = accountManager.getAccount(String.valueOf(acc.id()));
                if (accById != null) {
                    System.out.println("Z konta ID: id=" + accById.id() + ", username=" + accById.username());
                }
            }

            db.disconnect();

        } catch (SQLException e) {
            System.err.println("Błąd bazy danych: " + e.getMessage());
        }
    }
}


